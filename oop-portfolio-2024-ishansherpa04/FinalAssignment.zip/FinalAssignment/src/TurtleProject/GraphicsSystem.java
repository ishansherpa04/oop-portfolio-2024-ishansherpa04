package TurtleProject;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.awt.event.*;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import uk.ac.leedsbeckett.oop.OOPGraphics;

public class GraphicsSystem extends OOPGraphics   {
	
	private JFileChooser selector;
	private String[] fullCommand;
	protected String command,parameter;
	int param;
	private boolean save = false, penDown = false;
	Graphics diagram;
	JMenuBar menuBar;
	JMenu menuInfo, menuFile;
	JMenuItem menuItemAbout,menuItemLoad,menuItemSave;
	JLabel label1;
	
	public GraphicsSystem() {
		JFrame MainFrame = new JFrame();
		MainFrame.add(this);
		MainFrame.pack();
		MainFrame.setVisible(true);
		setDirection();
		this.selector= new JFileChooser();
		menuBar = new JMenuBar();
		MainFrame.setJMenuBar(menuBar);
		about();

	}
		
		private void drawTriangle() {
	        String input = JOptionPane.showInputDialog("Enter the length of the triangle's side:");
	        if (input != null) {
	            try {
	                int length = Integer.parseInt(input);
	                penDown();
	                for (int i = 0; i < 3; i++) {
	                    forward(length);
	                    turnRight(120);
	                }
	                penUp();
	            } 
	            catch (NumberFormatException e) {
	                JOptionPane.showMessageDialog(null, "Invalid length", "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    }
	    
	    private void drawTriangle2() {
	        boolean validInput = false;
	        int side1 = 0;
	        int side2 = 0;
	        int side3 = 0;

	        while (!validInput) {
	            String input1 = JOptionPane.showInputDialog("Enter the length of the first side:");
	            String input2 = JOptionPane.showInputDialog("Enter the length of the second side:");
	            String input3 = JOptionPane.showInputDialog("Enter the length of the third side:");

	            if (input1 != null && input2 != null && input3 != null) {
	                try {
	                    side1 = Integer.parseInt(input1);
	                    side2 = Integer.parseInt(input2);
	                    side3 = Integer.parseInt(input3);

	                    if (isValidTriangle(side1, side2, side3)) {
	                        validInput = true;
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Invalid triangle lengths", "Error", JOptionPane.ERROR_MESSAGE);
	                    }
	                } catch (NumberFormatException e) {
	                    JOptionPane.showMessageDialog(null, "Invalid input", "Error", JOptionPane.ERROR_MESSAGE);
	                }
	            } else {
	                // User canceled the input, exit the method
	                return;
	            }
	        }

	        penDown();
	        forward(side1);
	        turnRight(findAngle(side1, side2, side3));
	        forward(side2);
	        turnRight(findAngle(side2, side3, side1));
	        forward(side3);
	        penUp();
	    }

	    private int findAngle(int a, int b, int c) {
	        double angleRad = Math.acos((a*a + b*b - c*c) / (2.0 * a * b));
	        int angleDeg = (int) Math.toDegrees(angleRad);
	        return 180 - angleDeg;
	    }


	    private boolean isValidTriangle(int side1, int side2, int side3) {
	        return (side1 + side2 > side3) && (side2 + side3 > side1) && (side3 + side1 > side2);
	    }
	    
	
	    private void randomPattern() {
	        String input = JOptionPane.showInputDialog("Enter the number of pixels to move:");
	        if (input != null) {
	            try {
	                int pixels = Integer.parseInt(input);
	                penDown();

	                Random random = new Random();
	                int totalDistance = 0;

	                while (totalDistance < pixels) {
	                    int angle = random.nextInt(360);
	                    int distance = random.nextInt(50) + 1; // Random distance between 1 and 50 pixels

	                    if (totalDistance + distance > pixels) {
	                        distance = pixels - totalDistance; // Adjust distance to reach the desired number of pixels
	                    }

	                    forward(distance);
	                    turnRight(angle);

	                    totalDistance += distance;
	                }

	                penUp();
	            } catch (NumberFormatException e) {
	                JOptionPane.showMessageDialog(null, "Invalid input", "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        }
	    }

    
	    
	    
	public void setDirection() 
	{
		turnLeft();
	}
	
	public void srgb(int r,int g,int b) {
	    Color col = new Color(r,g,b);
	    setPenColour(col);
	    }
	
	private void drawSquare() {
	    boolean validInput = false;
	    int sideLength = 0;

	    while (!validInput) {
	        String input = JOptionPane.showInputDialog("Enter the length of the side:");
	        
	        if (input != null) {
	            try {
	                sideLength = Integer.parseInt(input);

	                if (sideLength > 0) {
	                    validInput = true;
	                } else {
	                    JOptionPane.showMessageDialog(null, "Invalid side length", "Error", JOptionPane.ERROR_MESSAGE);
	                }
	            } catch (NumberFormatException e) {
	                JOptionPane.showMessageDialog(null, "Invalid input", "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        } else {
	            // User canceled the input, exit the method
	            return;
	        }
	    }

	    penDown();
	    for (int i = 0; i < 4; i++) {
	        forward(sideLength);
	        turnRight(90);
	    }
	    penUp();
	}

	
	public void loadFile()
	{
		selector.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		selector.setDialogTitle("Open a File");
		int state = selector.showOpenDialog(null);
		if(state != JFileChooser.APPROVE_OPTION)
		{
			displayMessage("Try Again!");
		}
		else {
			
			File inputFile = selector.getSelectedFile();
			try {
				BufferedImage img = ImageIO.read(inputFile);
				setBufferedImage(img);
			}
			catch(IOException e) {
				
			}
		}
	}

	public void saveFile()
	{
		selector.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		selector.setDialogTitle("Save a File");
		int state = selector.showSaveDialog(null);
		if(state != JFileChooser.APPROVE_OPTION)
		{
			displayMessage("Try Again!");
		}
		else {
			try {
				File outputFile = selector.getSelectedFile();
				ImageIO.write(getBufferedImage(), "png", outputFile);
				save = true;
			} catch (IOException e) {
				
			}
		}
	}
	
	public void exit() {
        System.exit(0);
    }

	private void drawSpiral() {
		String input = JOptionPane.showInputDialog("Enter the number of iterations:");
	    if (input != null) {
	        try {
	            int iterations = Integer.parseInt(input);
	            int angle = 30; // Adjust the angle to change the spiral shape
	            int distance = 5; // Adjust the distance to make lines closer

	            penDown();
	            for (int i = 0; i < iterations; i++) {
	                // Set a different color for each iteration
	                Color color = Color.getHSBColor((float) i / iterations, 1, 1);
	                setPenColour(color);

	                forward((i + 1) * distance);
	                turnRight(angle);
	            }
	            penUp();
	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(null, "Invalid input", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }
	}

	
	public void clearNew() {
		if(getBackground_Col() != Color.black)
		setBackground_Col(Color.black);
		
	}
		
	public void backward(int parameter) {
		turnRight(180);
		forward(parameter);
		turnRight(180);
	}
	
	private void drawStarInput() {
	    String input = JOptionPane.showInputDialog("Enter the size of the star:");
	    if (input != null) {
	        try {
	            int size = Integer.parseInt(input);
	            drawStar(size);
	        } catch (NumberFormatException e) {
	            JOptionPane.showMessageDialog(null, "Invalid input", "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }
	}
	
	private void drawStar(int size) {
	    penDown();
	    for (int i = 0; i < 5; i++) {
	        forward(size);
	        turnRight(144);
	    }
	    penUp();
	}
	
	public void randomColor()
	{
		Random rgb = new Random();
		setPenColour(new Color(rgb.nextInt(256),rgb.nextInt(256),rgb.nextInt(256)));
	}
	
	public void penWidth(int width) {

		setStroke(width);

		}
	@Override
	public void about() {
		clear();
		
		penUp();
		setStroke(10);
		setxPos(90);
		setyPos(150);
		
		//For Letter "I"
		setPenColour(Color.red);
		turnRight(90);
		penDown();
		forward(90);
		turnLeft(110);
		penUp();
		
		//For Letter "S"
		reset();
		setStroke(10);
	    setPenColour(Color.white);
		setxPos(200);
		setyPos(150);
		turnRight(90);
		penDown();
		forward(60);
		turnLeft(90);
		forward(50);
		turnLeft(90);
		forward(60);
		turnRight(90);
		forward(50);
		turnRight(90);
		forward(60);
		
		//For Letter "H"
		reset();
		setStroke(10);
		setPenColour(Color.cyan);
		setxPos(240);
		setyPos(150);
		turnRight(90);
		penDown();
		turnLeft(90);
		forward(90);
		turnRight(180);
		forward(50);
		turnRight(90);
		forward(60);
		turnRight(90);
		forward(50);
		turnRight(180);
		forward(90);
		
		//For Letter "A"
		reset();
		setStroke(10);
		setPenColour(Color.magenta);
		setxPos(380);
		setyPos(150);
		turnLeft(35);
		penDown();
		forward(110);
		penUp();
		setxPos(380);
		setyPos(150);
		turnRight(65);
		penDown();
		forward(110);
		turnRight(180);
		forward(35);
		turnRight(60);
		forward(75);
		
		//For Letter "N"
		reset();
		setStroke(10);
		setPenColour(Color.green);
		setxPos(480);
		setyPos(150);
		penDown();
		turnLeft(90);
		turnRight(90);
		forward(110);
		penUp();
		setxPos(480);
		setyPos(150);
		turnLeft(35);
		penDown();
		forward(120);
		turnRight(35);
		turnLeft(180);
		forward(100);
		penUp();
		
	}
			
	public void menuBarOption() {
		menuItemAbout.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			about();
		}
		});
	menuItemLoad.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(save == false && penDown == true)
				displayMessage("Save First!");
			else
				loadFile();
		}
	});
	menuItemSave.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			saveFile();
		}
	});
	
	}
	
	public void processCommand(String command)
	{
		fullCommand = command.split(" ");
		if(fullCommand.length == 2) {
			parameter = fullCommand[1];
			
	    			
		switch(fullCommand[0])
		{
		
		case "pencolour":
            try {
                String[] rgbValues = parameter.split(",");
                if (rgbValues.length == 4) {
                    int r = Integer.parseInt(rgbValues[1].trim());
                    int g = Integer.parseInt(rgbValues[2].trim());
                    int b = Integer.parseInt(rgbValues[3].trim());
                    srgb(r, g, b);
                    displayMessage("Setting pen color to RGB: " + r + ", " + g + ", " + b);
                } else {
                    displayMessage("Invalid RGB values");
                }
            } catch (NumberFormatException e) {
                displayMessage("Invalid parameter");
            }
            break;
            
		case "penwidth":
            try {
                int width = Integer.parseInt(parameter);
                penWidth(width);
                displayMessage("Setting pen width to: " + width);
            } catch (NumberFormatException e) {
                displayMessage("Invalid parameter");
            }
            break;
		
            
		case "forward":
			
			try
			{
				if(Integer.parseInt(parameter) <= 500 && Integer.parseInt(parameter) > 0 && getxPos() !=0) {
					param = Integer.parseInt(parameter);
					this.forward(param);
					displayMessage("Goes forward " + param + " px");
					
					if(getyPos() < 0) {
						setyPos(0);
						displayMessage("Parameter taking out of bound (y-axis)");
					}
					else if(getyPos() > 400) {
						setyPos(300);
						displayMessage("Parameter taking out of bound (y-axis");
					}
					
				}
				else
					displayMessage("Parameter out of bound");
			}
			
			catch(NumberFormatException e) {
				displayMessage("Invalid parameter");
			}
			
		break;
		
		case "turnright":
			
			try
			{
				if(Integer.parseInt(parameter) <= 360) {
					param = Integer.parseInt(parameter);
					displayMessage("Turns Right " + param + " degrees");
				}
				else
					displayMessage("Parameter out of bound");
			}
			catch(NumberFormatException e) {
				displayMessage("Invalid parameter!");
			}
			this.turnRight(param);
			
			
		break;
		
			
		case "turnleft":
			try
			{	if(Integer.parseInt(parameter) <= 360) {
					param = Integer.parseInt(parameter);
					displayMessage("Turn left " + param + " degrees");
			}
			else
				displayMessage("Parameter out of bound");
			
			}
			catch(NumberFormatException e)
			{
				displayMessage("Invalid parameter");
			}
			this.turnLeft(param);
		break;
		
		case "backward":
			try
			{
				if(Integer.parseInt(parameter) <= 500 && Integer.parseInt(parameter) > 0 && getxPos() != 0) {
					param = Integer.parseInt(parameter);
					displayMessage("Goes Backward " + param + " px");
				}
				else
					displayMessage("Parameter out of bound ");
			}
			catch(NumberFormatException e) {
				displayMessage("Invalid parameter");
			}
			this.backward(param);
			break;
			
		default: displayMessage("No parameters");
		}
	}
		else if(fullCommand.length == 1) {
			switch(fullCommand[0]) {
			case "Pendown":penDown(); penDown = true; displayMessage("Pen is in use");
			break;
			case "Penup":penUp(); displayMessage("Pen not in use");
			break;
			case "Red":setPenColour(Color.red); displayMessage("Pen color set to Red");
			break;
			case "Green":setPenColour(Color.green); displayMessage("Pen color set to Green");
			break;
			case "Blue":setPenColour(Color.blue); displayMessage("Pen color set to Blue");
			break;
			case "Black":setPenColour(Color.black); displayMessage("Pen color set to Black");
			break; 
			case "White":setPenColour(Color.white); displayMessage("Pen color set to White");
			break;
			case "Clear":clearNew();clear(); displayMessage("Clear Command Called");
			break;
			case "Reset":reset();setDirection();clearInterface(); displayMessage("Reset Command Called");
			break;
			case "Save":saveFile(); displayMessage("Save Command Called");
			break;
			case "Load": displayMessage("Load Command Called");
				try {
					if(save == false && penDown == true) {
						displayMessage("Save First!");
					}
					else
						loadFile();
				}
				catch(Exception e) {
					
				}
			break;
			case "etriangle": drawTriangle(); displayMessage("Drawing an Equilateral triangle");
            break;
			case "triangle": drawTriangle2(); displayMessage("Drawing a Triangle");
            break;
			case "randomcolour": randomColor(); displayMessage("Setting colour to random");
			break;
			case "turnright":turnRight(); displayMessage("Turns Right 90 degrees");
			break;
			case "turnleft":turnLeft(); displayMessage("Turns Left 90 Degrees");
			break;
			case "xpos":System.out.println(getxPos());
			break;
			case "ypos":System.out.println(getyPos());
			break;
			case "square": drawSquare(); displayMessage("Drawing a Square");
            break;
			case "star": drawStarInput(); displayMessage("Drawing a Star");
            break;
			case "randompattern": randomPattern(); displayMessage("Random");
			break;
			case "spiral": drawSpiral(); displayMessage("Spiral");
			break;
			case "about":about();
			break;
			case "exit","quit":exit();
			break;
			default:displayMessage("Invalid Command");
			}
		}
		
		
		else {
			displayMessage("Command out of bounds");
		}
	}
}


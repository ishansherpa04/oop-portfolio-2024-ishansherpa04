package TurtleProject;

public class MainClass{
	public static void main(String[] args) {
		GraphicsSystem GraphicsSystem = new GraphicsSystem();

	}
}